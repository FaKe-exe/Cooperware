#pragma once

#include "../Singleton.hpp"
extern void xdSkinchanger();
extern void NetvarHook();