#include "mem.h"


uint32_t runtime_basis = seed;



















