#pragma once
const char* wps []
{
	"auto",
	"scout",
	"awp",
	"heavy pistol",
	"other",
};
const char* WeaponType []
{
	"name",
	"icon",
	"amount",
};
const char* ChamsMaterials []
{
	"textured",
	"flat",
	"metallic",
	"pulsing",
	"glow",
	"eso glow",
};
const char* aimlegitrtype []
{
	"solid",
	"sleek",
	"reserved",
};
const char* hitsounds []
{
	"off",
	"skeet",
	"rifk7",
	"bameware",
};
const char* hitbxlegit []
{
	"head",
	"neck",
	"chest",
	"nearest",
};
const char* dttt []
{
	"off",
	"onkey",
	"constant",
};
const char* pitchzzz []
{
	"off",
	"emotion",
	"fake up",
	"fake down",
};
const char* pitchzzz2[]
{
	"off",
	"backwards",
	"manual",
	"test",
};
const char* desynbc []
{
	"off",
	"static",

};
const char* GlowStyles []
{
	"normal",
	"pulsing",
	"outline",
	"pulsing outline",
};