#pragma once
#include "../valve_sdk/sdk.hpp"
#include "../valve_sdk/csgostructs.hpp"

#include <deque>
#include "animfix.h"

namespace LagComp
{










}